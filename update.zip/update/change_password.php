<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (isset($_POST['oldpassword'])) {
	$oldpassword = md5($_POST['oldpassword']);
	$email = $_SESSION['userid'];
	$newpassword = md5($_POST['newpassword']);

	$query = "SELECT * FROM user WHERE email = '".$email."' AND password = '".$oldpassword."'" ;
	$result = mysqli_query($con,$query);

	if (mysqli_num_rows($result) > 0) {
		$sql = "UPDATE user SET password ='".$newpassword."' WHERE email='".$email."'";
		if ($con->query($sql) === TRUE) {
				   $response = array(
			  		'status' => 'success',
			  		'data' =>'OK'
			  	);
			  	  echo json_encode($response);
			} else {
				   $response = array(
			  		'status' => 'error',
			  		'data' =>'password updated'
			  	);
			  	  echo json_encode($response);
			}
	}else{
		$response = array(
		  		'status' => 'oldpassword',
		  		'data' =>'error oldpassword not matched'
		  	);
		  	  echo json_encode($response);

	}
} else {
	$response = array(
		  		'status' => 'error',
		  		'data' =>'error cross checking'
		  	);
		  	  echo json_encode($response);
}



?>
