<div class="w3-agile-footer">
		<div class="container">
			<div class="footer-grids">
				<div class="col-md-6 footer-grid">
					<div class="footer-grid-heading">
						<h4>Usefull Links</h4>
					</div>
					<div class="footer-grid-info">
					<ul>
					<li><a href="https://www.service.transport.qld.gov.au/practiceroadrulestest/public/Welcome.xhtml?dswid=3554" target="_blank">Practice Test</a></li>
					<li><a href="https://www.qld.gov.au/transport/licensing/getting/tests" target="_blank">Book Driving Test </a></li>
					</ul>
					</div>
				</div>
				<div class="col-md-6 footer-grid">
					<div class="footer-grid-heading">
						<h4>Navigation</h4>
					</div>
					<div class="footer-grid-info">
						<ul>
							<li><a href="index.php">Home</a></li>
							<li><a href="aboutus.php">About</a></li>
							<li><a href="packages.php">packages</a></li>
							<li><a href="enquiry-form.php">Enquiry</a></li>
							<li><a href="apply-form.php">Apply Now</a></li>
						</ul>
					</div>
				</div>
				
				<div class="clearfix"> </div>
			</div>
			<div class="agileits-G-copyright">
				<p>© 2020 G and R Driving School . All Rights Reserved</p>
			</div>
		</div>
	</div>