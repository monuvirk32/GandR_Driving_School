<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
//index.php
//Include Configuration File
include('googleconfig.php');
include('fbconfig.php');
//This $_GET["code"] variable value received after user has login into their Google Account redirct to PHP script then this variable value has been received
if(isset($_GET["code"]))
{

 //It will Attempt to exchange a code for an valid authentication token.

 $token = $google_client->fetchAccessTokenWithAuthCode($_GET["code"]);



 //This condition will check there is any error occur during geting authentication token. If there is no any error occur then it will execute if block of code/

 if(!isset($token['error']))

 {

  //Set the access token used for requests

  $google_client->setAccessToken($token['access_token']);



  //Store "access_token" value in $_SESSION variable for future use.

  $_SESSION['access_token'] = $token['access_token'];



  //Create Object of Google Service OAuth 2 class

  $google_service = new Google_Service_Oauth2($google_client);



  //Get user profile data from google

  $data = $google_service->userinfo->get();

  //get data

  $_SESSION["userid"] = $data["email"];

 }



/* echo "<pre>";
 print_r ($data);
 echo "</pre>";*/
/**/
}
/*$facebook_login_url ='';
$facebook_helper = $facebook->getRedirectLoginHelper();
if(isset($_GET['code']))
{
 if(isset($_SESSION['access_token']))
 {
  $access_token = $_SESSION['access_token'];
 }
 else
 {
  $access_token = $facebook_helper->getAccessToken();
  $_SESSION['access_token'] = $access_token;
  $facebook->setDefaultAccessToken($_SESSION['access_token']);
 }
 $_SESSION['user_id'] = '';
 $_SESSION['user_name'] = '';
 $_SESSION['user_email_address'] = '';
 $_SESSION['user_image'] = '';
 $graph_response = $facebook->get("/me?fields=name,email", $access_token);
 $facebook_user_info = $graph_response->getGraphUser();
 $_SESSION['userid'] = $facebook_user_info['email'];
 if(!empty($facebook_user_info['id']))
 {
  $_SESSION['user_image'] = 'http://graph.facebook.com/'.$facebook_user_info['id'].'/picture';
 }
  if(!empty($facebook_user_info['name']))
{
  $_SESSION['user_name'] = $facebook_user_info['name'];
 }
 if(!empty($facebook_user_info['email']))
 {
  $_SESSION['user_email_address'] = $facebook_user_info['email'];
 }
}
else
{
 // Get login url
    $facebook_permissions = ['email']; // Optional permissions
    $facebook_login_url = $facebook_helper->getLoginUrl('http://localhost/project/index.php', $facebook_permissions);
    // Render Facebook login button
    $facebook_login_url = '<div align="center"><a href="'.$facebook_login_url.'"><img src="https://miro.medium.com/fit/c/1838/551/1*InDQe4dYjE72rNr37TVI1Q.png" /></a></div>';
}
*/
?>
<div class="header">
		<div class="header_left">
			<ul>
				<li><span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>Gold Coast,QLD</li>
				<li><span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>0499 180 399</li>
				<li><span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>support@email.com</li>
				
			</ul>
		</div>
		<div class="header_right">
			<a href="#"><span data-hover="Admin Login" style="color: white">Admin</span></a>
		
		</div>
		
			<div class="clearfix"></div>
		
	</div>
	<div class="header-bottom">
		<nav class="navbar navbar-default">
			<div class="navbar-header navbar-left">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<h1><a  href="index.php"><img src="images/logo.png" height=auto; width=150px; alt="" ></a></h1>
			</div>
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
				<nav class="link-effect-2" id="link-effect-2">
					<ul class="nav navbar-nav">
						<li><a href="index.php"><span data-hover="Home">Home</span></a></li>
						<li><a href="#"><span data-hover="About Us">About Us</span></a></li>
					    <li><a href="packages.php"><span data-hover="Packages">Packages</span></a></li>
						<?php if (!$_SESSION['userid']) { ?>

                          <a href="#" data-toggle="modal" data-target="#exampleModal"><span data-hover="Apply Now">Apply Now</span></a>

						<?php } 
							?>
							<?php if ($_SESSION['userid']) { ?>
						<li><a href="apply-form.php"><span data-hover="Apply Now">Apply Now</span></a></li>
						<a href="logout.php"><span data-hover="Logout">Logout</span></a>
						<?php } ?>
					    <li><a href="contactus.php"><span data-hover="Contact Us">Contact Us</span></a></li>
                        <li><a href="enquiry-form.php"><span data-hover="Enquiry">Enquiry</span></a></li>
					</ul>
				</nav>
			</div>
			
		</nav>
	</div>
	<!-- Modal -->

<div class="modal fade" data-backdrop="static" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

<div class="modal-dialog" role="document">

  <div class="modal-content">

	<div class="modal-header">

	  <h5 class="modal-title" id="exampleModalLabel">Login / Signup</h5>

	</div>

	<div class="modal-body" style="padding: 20px;">

	  

	  <form id="login_form">

		  <h3>Login</h3>

		  <hr>

		  <div class="msg"></div>

		  <label>Email ID<span class="text-danger">*</span></label>

		  <input type="email" name="email" required class="form-control email">

		  

		  <label>Password<span class="text-danger">*</span></label>

		  <input type="password" name="password" required class="form-control password">

		  <br>

		  <button class="btn btn-info" id="login_btn">Login Now</button> OR <a href="#" id="sign_up">Signup</a>

		  <hr>

		  <div class="row text-center">

			  <div class="col-xs-12 col-md-6" style="margin-top: 10px;">

				  <a href="<?php echo $google_client->createAuthUrl(); ?>"><button type="button" class="btn btn-danger" style="padding:5px 20px;">Login With Gmail</button></a>

			  </div>

			  <div class="col-xs-12 col-md-6" style="margin-top: 10px;">

				  <a href="<?php echo $facebook_login_url; ?>"><button type="button" class="btn btn-primary" style="padding:5px 20px;">Login With Facebook</button></a>

			  </div>

		  </div>

	  </form>

	  <form id="signup_form" style="display: none;">

		  <h3>Signup</h3>

		  <hr>

		  <div class="msg2"></div>

		  <label>Name<span class="text-danger">*</span></label>

		  <input type="text" name="fullname" required class="form-control fullname">

		  <br>

		  <label>Password<span class="text-danger">*</span></label>

		  <input type="password" name="password" required class="form-control c_password">

		  <br>

		  <label>Email<span class="text-danger">*</span></label>

		  <input type="email" name="email" required class="form-control c_email">

		  <br>

		  <button class="btn btn-info" id="create_account">Create Account</button> OR <a href="#" id="log_up">Login</a>

	  </form>

	</div>

	<div class="modal-footer">

	  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

	</div>

  </div>

</div>

</div>



<script type="text/javascript">

  $('#login_btn').click(function(e){

	  e.preventDefault();

	  var data = $('#login_form').serialize();

	  var emailaddress = $('.email').val();

	  if ($('.email').val()=='' || $('.password').val()=='') {

		  $('.msg').html('<h6 class="alert alert-danger">Please fill out the form correctly.</h6>');

	  } else {

		  if( !validateEmail(emailaddress)){

			 $('.msg').html('<h6 class="alert alert-danger">Invalid Email Address</h6>');

		  }else{

			  $.ajax({

				  url:'login_check.php',

				  method:"POST",

				  data:data,

				  dataType:"JSON",

				  success:function(res){

					  if (res.status == 'success') {

						  $('#login_form').trigger('reset');

						  window.location.href = "apply-form.php";

					  } else {

						  $('.msg').html('<h6 class="alert alert-danger">Invalid Username or Password</h6>');

					  }



				  }

			  });

		  }

		  

	  }

	  

  });

  $('#sign_up').click(function(){

	  $('#login_form').hide();

	  $('#signup_form').show();

  });

  $('#log_up').click(function(){

	  $('#login_form').show();

	  $('#signup_form').hide();

  });

  $('#create_account').click(function(e){

	  e.preventDefault();

	  var data = $('#signup_form').serialize();

	  var emailaddress = $('.c_email').val();

	  if ($('.fullname').val()=='' || $('.c_password').val()=='' || $('.c_email').val()=='') {

		  $('.msg2').html('<h6 class="alert alert-danger">Please fill out the form correctly.</h6>');

	  } else {

		  if( !validateEmail(emailaddress)){

			 $('.msg2').html('<h6 class="alert alert-danger">Invalid Email Address</h6>');

		  }else{

			  $.ajax({

				  url:"form_submit.php",

				  method:"POST",

				  data:data,

				  dataType:"JSON",

				  success:function(res){

					  if (res.status == 'success') {

						  alert('Successs');

						  $('.msg2').html('');

						  $('#signup_form').trigger('reset');

						  window.location.href = "apply-form.php";

					  } else {

						  alert('NO Sir');

					  }



				  }

			  });

		  }

		  

	  }

	  

  });

   function validateEmail($email) {

	var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;

	return emailReg.test( $email );

  }

  

</script>

	