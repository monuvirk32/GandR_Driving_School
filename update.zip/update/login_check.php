<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');

$email = $_POST['email'];
$password = $_POST['password'];

$query = "SELECT * FROM user WHERE email  = '".$email."' AND password = '".$password."'" ;
$result = mysqli_query($con,$query);
$ret=mysqli_query($con,"select RegNumber from tbluser where Email='$email'");
$resultR=mysqli_fetch_array($ret);
if (mysqli_num_rows($result) == 1) {
   $response = array(
		'status' => 'success',
		'data' =>'OK'
	);
$rs = mysqli_fetch_assoc($result);
$_SESSION['regno']=$resultR['RegNumber'];
$_SESSION['user_fullname'] = $rs['fullname'];
	$_SESSION["userid"] = $email;

	echo json_encode($response);
} else {
	$response = array(
		'status' => 'error',
		'data' =>'error'
	);
	echo json_encode($response);

}

 ?>
